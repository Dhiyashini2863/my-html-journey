// src/components/Sidebar.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FaHome, FaEdit, FaListAlt, FaSignOutAlt } from 'react-icons/fa'; // Import icons
import './Sidebar.css';

const Sidebar = ({ onLogout }) => {
  const { empId, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="sidebar">
      <div className="employee-info">
        <p>Employee ID: {empId}</p>
      </div>
      <ul>
        <li><Link to="/dashboard" className="sidebar-link"><FaHome className="icon" /> Dashboard</Link></li>
        <li><Link to="/update-timesheet" className="sidebar-link"><FaEdit className="icon" /> Update Timesheet</Link></li>
        <li><Link to="/view-timesheet" className="sidebar-link"><FaListAlt className="icon" /> View Timesheet</Link></li>
      </ul>
      <div className="employee-info">
        <button className="logout-button" onClick={handleLogout}><FaSignOutAlt /> Logout</button>
      </div>
    </div>
  );
};

export default Sidebar;
