import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import timesheetService from '../services/timesheetService';
import axios from 'axios';
import './UpdateTimesheet.css';

function UpdateTimesheet() {
    document.title = 'Update Timesheet | Employee';
    const [timesheets, setTimesheets] = useState([]);
    const [date, setDate] = useState('');
    const [projectName, setProjectName] = useState('');
    const [projectModule, setProjectModule] = useState('');
    const [modules, setModules] = useState([]); // State for modules
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [comments, setComments] = useState('');
    const [showPopup, setShowPopup] = useState(false);
    const [hoveredTimesheet, setHoveredTimesheet] = useState(null);
    const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const { empId } = useAuth(); // Get empId from context

    useEffect(() => {
        if (empId) {
            loadTimesheets();
        } else {
            alert('Employee ID not found');
        }
    }, [empId, currentMonth, currentYear]);

    useEffect(() => {
        if (projectName) {
            fetchModules(projectName);
        }
    }, [projectName]);

    const loadTimesheets = async () => {
        try {
            const response = await timesheetService.getTimesheets(empId);
            setTimesheets(response.data);
        } catch (error) {
            alert("Error loading timesheets");
        }
    };

    const fetchModules = async (projectName) => {
        try {
            const response = await axios.get(`/api/modules?project_name=${projectName}`);
            setModules(response.data);
        } catch (error) {
            console.error('Failed to fetch modules', error);
        }
    };

    const handleAddTimesheet = async (e) => {
        e.preventDefault();

        const startTimeObj = new Date(`${date}T${startTime}`);
        const endTimeObj = new Date(`${date}T${endTime}`);
        const hours = (endTimeObj - startTimeObj) / (1000 * 60 * 60);

        if (hours <= 0) {
            alert("End time must be after start time");
            return;
        }

        const dayTimesheets = timesheets.filter(t => t.date === date);
        const totalHoursForDay = dayTimesheets.reduce((sum, t) => sum + parseFloat(t.total_hours), 0) + hours;

        if (totalHoursForDay > 24) {
            alert("Total hours for the day exceed 24 hours. Please adjust the times.");
            return;
        }

        try {
            await timesheetService.addTimesheet(empId, date, projectName, projectModule, startTime, endTime, comments);
            loadTimesheets();
            setShowPopup(false);
        } catch (error) {
            alert("Error adding timesheet");
        }
    };

    const getRandomColor = () => {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
            color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    };

    const handlePrevMonth = () => {
        setCurrentMonth(prevMonth => prevMonth === 0 ? 11 : prevMonth - 1);
        setCurrentYear(prevYear => currentMonth === 0 ? prevYear - 1 : prevYear);
    };

    const handleNextMonth = () => {
        setCurrentMonth(prevMonth => prevMonth === 11 ? 0 : prevMonth + 1);
        setCurrentYear(prevYear => currentMonth === 11 ? prevYear + 1 : prevYear);
    };

    const renderCalendar = () => {
        const firstDay = new Date(currentYear, currentMonth, 1).getDay();
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
        const calendar = [];
        let dayCount = 1;

        const today = new Date();
        const past7Days = new Date(today);
        past7Days.setDate(today.getDate() - 7);

        for (let i = 0; i < 6; i++) {
            const week = [];
            for (let j = 0; j < 7; j++) {
                if ((i === 0 && j < firstDay) || dayCount > daysInMonth) {
                    week.push(<td key={`${i}-${j}`} className="calendar-cell empty"></td>);
                } else {
                    const dateString = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(dayCount).padStart(2, '0')}`;
                    const dayTimesheets = timesheets.filter(t => t.date === dateString);
                    const dateObj = new Date(dateString);
                    const isPast7Days = dateObj >= past7Days && dateObj < today; // Exclude today
                    const isFutureDate = dateObj >= today; // Include today as future date
                    const isSunday = j === 0;
                    const isToday = today.toISOString().split('T')[0] === dateString;

                    let additionalClass = '';
                    if (isToday) {
                        additionalClass = 'today';
                    } else if (isFutureDate && !isSunday) {
                        additionalClass = 'upcoming';
                    }

                    week.push(
                        <td
                            key={`${i}-${j}`}
                            className={`calendar-cell date-cell-container ${(!isPast7Days || isFutureDate) ? 'locked' : ''} ${additionalClass}`}
                            onClick={() => {
                                if (isPast7Days && !isToday && !isSunday) {
                                    setDate(dateString);
                                    setShowPopup(true);
                                }
                            }}
                        >
                            <div className="date-cell">
                                <span className="date-number">{dayCount}</span>
                                {isSunday ? (
                                    <div className="week-off">
                                        <span role="img" aria-label="smiley">😊</span> Week Off
                                    </div>
                                ) : (
                                    <div className="timesheet-circles">
                                        {dayTimesheets.map((timesheet, index) => (
                                            <div
                                                key={index}
                                                className="total-hours-circle"
                                                style={{ backgroundColor: getRandomColor() }}
                                                onMouseEnter={() => setHoveredTimesheet(timesheet)}
                                                onMouseLeave={() => setHoveredTimesheet(null)}
                                            >
                                                {Math.round(timesheet.total_hours)}
                                            </div>
                                        ))}
                                    </div>
                                )}
                                {isPast7Days && !isToday && !isSunday && dayTimesheets.length === 0 && (
                                    <button
                                        className="plus-button"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setDate(dateString);
                                            setShowPopup(true);
                                        }}
                                    >
                                        +
                                    </button>
                                )}
                            </div>
                        </td>
                    );
                    dayCount++;
                }
            }
            calendar.push(<tr key={i}>{week}</tr>);
        }

        return calendar;
    };

    return (
        <div className="update-timesheet">
            <div className="header">
                <div className="month-year-selector">
                    <select
                        className="month-selector"
                        value={currentMonth}
                        onChange={(e) => setCurrentMonth(Number(e.target.value))}
                    >
                        {Array.from({ length: 12 }, (_, i) => (
                            <option key={i} value={i}>
                                {new Date(0, i).toLocaleString('default', { month: 'long' })}
                            </option>
                        ))}
                    </select>
                    <select
                        className="year-selector"
                        value={currentYear}
                        onChange={(e) => setCurrentYear(Number(e.target.value))}
                    >
                        {Array.from({ length: 5 }, (_, i) => (
                            <option key={i} value={currentYear - 2 + i}>
                                {currentYear - 2 + i}
                            </option>
                        ))}
                    </select>
                </div>
                
                <div className="month-navigation">
                    <button onClick={handlePrevMonth}>Previous</button>
                    <button onClick={handleNextMonth}>Next</button>
                </div>
            </div>
            <table className="calendar-table">
                <thead>
                    <tr>
                        <th>Sun</th>
                        <th>Mon</th>
                        <th>Tue</th>
                        <th>Wed</th>
                        <th>Thu</th>
                        <th>Fri</th>
                        <th>Sat</th>
                    </tr>
                </thead>
                <tbody>
                    {renderCalendar()}
                </tbody>
            </table>
            {showPopup && (
                <div className="popup show">
                    <div className="popup-content">
                        <h3>Add Timesheet Entry</h3>
                        <form onSubmit={handleAddTimesheet}>
                            <label>
                                Date:
                                <input
                                    type="date"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                    max={new Date().toISOString().split('T')[0]}
                                    required
                                />
                            </label>
                            <label>
                                Project Name:
                                <input
                                    type="text"
                                    value={projectName}
                                    onChange={(e) => setProjectName(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Project Module:
                                <select
                                    value={projectModule}
                                    onChange={(e) => setProjectModule(e.target.value)}
                                    required
                                >
                                    <option value="">Select a module</option>
                                    {modules.map((module) => (
                                        <option key={module.id} value={module.name}>
                                            {module.name}
                                        </option>
                                    ))}
                                </select>
                            </label>
                            <label>
                                Start Time:
                                <input
                                    type="time"
                                    value={startTime}
                                    onChange={(e) => setStartTime(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                End Time:
                                <input
                                    type="time"
                                    value={endTime}
                                    onChange={(e) => setEndTime(e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Comments:
                                <textarea
                                    value={comments}
                                    onChange={(e) => setComments(e.target.value)}
                                    required
                                ></textarea>
                            </label>
                            <button type="submit">Add Entry</button>
                            <button type="button" onClick={() => setShowPopup(false)}>
                                Cancel
                            </button>
                        </form>
                    </div>
                </div>
            )}
            {hoveredTimesheet && (
                <div className="hover-popup">
                    <div>
                        <h3>Timesheet Details</h3>
                        <p><strong>Date:</strong> {hoveredTimesheet.date}</p>
                        <p><strong>Project Name:</strong> {hoveredTimesheet.project_name}</p>
                        <p><strong>Project Module:</strong> {hoveredTimesheet.project_module}</p>
                        <p><strong>Start Time:</strong> {hoveredTimesheet.start_time}</p>
                        <p><strong>End Time:</strong> {hoveredTimesheet.end_time}</p>
                        <p><strong>Total Hours:</strong> {hoveredTimesheet.total_hours}</p>
                        <p><strong>Comments:</strong> {hoveredTimesheet.comments}</p>
                    </div>
                </div>
            )}
        </div>
    );
}

export default UpdateTimesheet;
