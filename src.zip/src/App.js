import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import UpdateTimesheet from './components/UpdateTimesheet';
import ViewTimesheet from './components/ViewTimesheet';
import Login from './components/Login';
import LeadPage from './components/LeadPage';
import ManagerPage from './components/ManagerPage';
import { AuthProvider, useAuth } from './context/AuthContext';
import './App.css';

const App = () => {
    return (
        <AuthProvider>
            <Router>
                <div className="app">
                    <Content />
                </div>
            </Router>
        </AuthProvider>
    );
};

const Content = () => {
    const { empId } = useAuth();
    const location = useLocation();

    const showSidebar = empId && !['/lead', '/manager'].includes(location.pathname);

    return (
        <>
            {showSidebar && <Sidebar />}
            <div className={showSidebar ? 'content' : ''}>
                <Routes>
                    <Route path="/" element={<Navigate to={empId ? "/dashboard" : "/login"} />} />
                    <Route path="/login" element={<Login />} />
                    {empId && (
                        <>
                            <Route path="/dashboard" element={<Dashboard />} />
                            <Route path="/update-timesheet" element={<UpdateTimesheet />} />
                            <Route path="/view-timesheet" element={<ViewTimesheet />} />
                            <Route path="/lead" element={<LeadPage />} />
                            <Route path="/manager" element={<ManagerPage />} />
                        </>
                    )}
                    <Route path="*" element={<Navigate to={empId ? "/dashboard" : "/login"} />} />
                </Routes>
            </div>
        </>
    );
};

export default App;
